

<?php $__env->startSection('main'); ?>
<section class="section-4 bg-2">    
    <div class="container pt-5">
        <div class="row">
            <div class="col">
                <nav aria-label="breadcrumb" class=" rounded-3 p-3">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>"><i class="fa fa-arrow-left" aria-hidden="true"></i> &nbsp;Back to Jobs</a></li>
                    </ol>
                </nav>
                <?php echo $__env->make('front.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div> 
    </div>
    <div class="container job_details_area">
        <div class="row pb-5">
            <div class="col-md-8">
                <div class="card shadow border-0">
                    <div class="job_details_header">
                        <div class="single_jobs white-bg d-flex justify-content-between">
                            <div class="jobs_left d-flex align-items-center">
                                
                                <div class="jobs_conetent">
                                    <a href="#">
                                        <h4><?php echo e($job->title); ?></h4>
                                    </a>
                                    <div class="links_locat d-flex align-items-center">
                                        <div class="location">
                                            <p> <i class="fa fa-map-marker"></i> <?php echo e($job->location); ?></p>
                                        </div>
                                        <div class="location">
                                            <p> <i class="fa fa-clock-o"></i> <?php echo e($job->job_type->name); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="jobs_right">
                                <div class="apply_now">
                                    <a class="heart_mark  <?php echo e(($count == 1) ? 'saved-job' : ''); ?>" href="javascript:void(0)" onclick="saveJob(<?php echo e($job->id); ?>)">  <i class="fa fa-heart-o" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="descript_wrap white-bg">
                        <div class="single_wrap">
                            <h4>Job description</h4>
                            <?php echo nL2br($job->description); ?>

                        </div>
                        <?php if(!empty($job->responsibility)): ?>
                            <div class="single_wrap">
                                <h4>Responsibility</h4>
                                <?php echo nL2br($job->responsibility); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(!empty($job->qualification)): ?>
                            <div class="single_wrap">
                                <h4>Qualifications</h4>
                                <?php echo nL2br($job->qualification); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(!empty($job->benefits)): ?>
                            <div class="single_wrap">
                                <h4>Benefits</h4>
                                <?php echo nL2br($job->benifits); ?>

                            </div>
                        <?php endif; ?>
                        <div class="border-bottom"></div>
                        <div class="pt-3 text-end">

                            <?php if(Auth::check()): ?>
                                <a href="javascript:void(0)" onclick="saveJob('<?php echo e($job->id); ?>')"  class="btn btn-secondary">Save</a>
                            <?php else: ?>
                                <a href="javascript:void(0)" class="btn btn-secondary" disabled>Login to Save</a>
                            <?php endif; ?>
                            
                            <?php if(Auth::check()): ?>
                                <a href="javascript:void(0)" onclick="applyJob('<?php echo e($job->id); ?>')" class="btn btn-primary">Apply</a>
                            <?php else: ?>
                                <a href="javascript:void(0)" class="btn btn-primary" disabled>Login to Apply</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                

                <?php if(Auth::user() && Auth::user()->id == $job->user_id): ?> 
                    <div class="card shadow border-0 mt-4">
                        <div class="job_details_header">
                            <div class="single_jobs white-bg d-flex justify-content-between">
                                <div class="jobs_left d-flex align-items-center">
                                    
                                    <div class="jobs_conetent">
                                            <h4>Applications</h4>
                                    </div>
                                </div>
                                <div class="jobs_right"></div>
                            </div>
                        </div>
                        <div class="descript_wrap white-bg">
                            <table class="table table-striped">
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Applied Date</th>
                            </tr>
                                
                                    <?php $__empty_1 = true; $__currentLoopData = $job_applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($job_application->user->name); ?></td>
                                            <td><?php echo e($job_application->user->email); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($job_application->applied_date)->format('d m-y')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td>No applications found</td>
                                    </tr>
                                    <?php endif; ?>
                                
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <div class="card shadow border-0">
                    <div class="job_sumary">
                        <div class="summery_header pb-1 pt-4">
                            <h3>Job Summery</h3>
                        </div>
                        <div class="job_content pt-3">
                            <ul>
                                <li>Published on: <span><?php echo e(\Carbon\Carbon::parse($job->created_at)->format('d M, Y')); ?></span></li>
                                <li>Vacancy: <span><?php echo e($job->vacancy); ?></span></li>
                                <?php if(!empty($job->salary)): ?>
                                    <li>Salary: <span><?php echo e($job->salary); ?></span></li>
                                <?php endif; ?>
                                <?php if(!empty($job->location)): ?>
                                    <li>Location: <span><?php echo e($job->location); ?></span></li>
                                <?php endif; ?>
                                <li>Job Nature: <span><?php echo e($job->job_type->name); ?></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card shadow border-0 my-4">
                    <div class="job_sumary">
                        <div class="summery_header pb-1 pt-4">
                            <h3>Company Details</h3>
                        </div>
                        <div class="job_content pt-3">
                            <ul>
                                <?php if(!empty($job->company_name)): ?>
                                    <li>Name: <span><?php echo e($job->company_name); ?></span></li>
                                <?php endif; ?>
                                <?php if(!empty($job->company_location)): ?>
                                    <li>Locaion: <span><?php echo e($job->company_location); ?></span></li>
                                <?php endif; ?>
                                <?php if(!empty($job->company_website)): ?>
                                    <li>Webite: <span><a href="<?php echo e($job->company_website); ?>" target="_blank"><?php echo e($job->company_website); ?></a></span></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title pb-0" id="exampleModalLabel">Change Profile Picture</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Profile Image</label>
                <input type="file" class="form-control" id="image"  name="image">
            </div>
            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mx-3">Update</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
            
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>
    <script>

        function applyJob(id){
            if (confirm("Are you sure you want to apply for this job")) {
                    $.ajax({
                        url: '<?php echo e(route('applyJob')); ?>',
                        type: 'post',
                        dataType: 'json',
                        data: {id:id},
                        success: function(response){
                            window.location.href="<?php echo e(url()->current()); ?>";
                        }
                    });
            }   
        }

        function saveJob(id){
                    $.ajax({
                        url: '<?php echo e(route('saveJob')); ?>',
                        type: 'post',
                        dataType: 'json',
                        data: {id:id},
                        success: function(response){
                            window.location.href="<?php echo e(url()->current()); ?>";
                        }
                    });
        }
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\mohitingh\job_portal\resources\views/front/jobDetail.blade.php ENDPATH**/ ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo e(Session('success')); ?>

        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="close"></button>
    </div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo e(Session('error')); ?>

        <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="close"></button>
    </div>
<?php endif; ?><?php /**PATH F:\xamp\htdocs\mohitingh\job_portal\resources\views/front/message.blade.php ENDPATH**/ ?>